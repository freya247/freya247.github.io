# MySQL
# Type the IP of your MySQL instance including port after the colon
dbhost = '127.0.0.1:3306'
# Type in your MySQL username
dbuser = 'jan'
# Type in your MySQL password
dbpass = '12345678abcdef'
# Static, do not change
dbname = 'iss_database_2'

# WTForms requirement
secret_key = '0a7rj3y2zqo9m95e'
